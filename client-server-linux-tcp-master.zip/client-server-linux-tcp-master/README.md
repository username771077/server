```
chmod a+x c.sh
chmod a+x s.sh
./c.sh
./s.sh
./server
```

Then in new terminal:

```
./client
```

