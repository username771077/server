gcc server.c erproc.c -W -Wall -Werror -o server
