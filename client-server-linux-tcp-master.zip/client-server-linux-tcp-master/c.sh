gcc client.c erproc.c -W -Wall -Werror -o client
